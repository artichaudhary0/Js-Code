// object : data type
/*
    Primitive : 
        boolean 
        string 
        symbol 
        number
        undefined 
        null 
        bigint 
    Non Primitive : 
        array => object
        object => object
        function => function   

*/

key - value;
const shape = {
  // (height , width ,)=> member variable/ attributes (isSquare , circle)=> member function/ method
  height: 100,
  width: 100,
  isSquare: function () {
    if (this.height == this.width) {
      return true;
    }
    return false;
  },
  circle: {
    radius: 50,
    area: function () {
      console.log("area");
    },
  },
};

console.log(shape.isSquare());

factory;
function circle(height) {
  return {
    height,
    width: 100,
    isSquare: function () {
      if (this.height == this.width) {
        return true;
      }
      return false;
    },
    circle: {
      radius: 50,
      area: function () {
        console.log("area");
      },
    },
  };
}

let obj = circle(100); // obj = {} object

console.log(obj.isSquare());

// constructor function

function Circle(radius) {
  console.log(this);
  this.bhavesh = radius;
  this.area = function () {
    console.log("Area of cicle is : ", 3.14 * this.bhavesh * this.bhavesh);
  };
}

let anotherObj = new Circle(100);

anotherObj.area();
