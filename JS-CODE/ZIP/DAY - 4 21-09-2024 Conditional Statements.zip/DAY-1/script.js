/* 
document.write() write on browser
alert() // dialogue box
innerHTML // write in tag
console.log()
*/

var grade = document.getElementById("marks");

console.log(grade);

var marks = prompt("Enter marks");

if (marks >= 0 && marks < 23) {
  grade.innerHTML = "F";
  console.log("F");
} else if (marks >= 23 && marks < 50) {
  grade.innerHTML = "D";
} else if (marks >= 50 && marks < 75) {
  grade.innerHTML = "C";
} else if (marks >= 75 && marks < 85) {
  grade.innerHTML = "B";
} else if (marks >= 85 && marks <= 100) {
  grade.innerHTML = "A";
} else {
  grade.innerHTML = "Invalid number!";
}

var namee = "Arti chaudhary"; // user input
var age = 23;
console.log("My name is : ", namee + " <br> my age : " + age);

document.write("My name is : ", namee + " <br> my age : " + age);

// document.getElementById("heading").innerHTML = namee;

// // document.write(namee + " " + age);
// alert(namee);
