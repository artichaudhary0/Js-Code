/*
DOM :
Documents object model.
*/

for (let i = 1; i < 10; i++) {
  let result = (document.getElementById("paragraph").innerText = "ikqeyvfwe8f");
  console.log(result);
}

window.console.log("Dom");
window.document.write("biuefb");
document.write("<br>Hello dom");
