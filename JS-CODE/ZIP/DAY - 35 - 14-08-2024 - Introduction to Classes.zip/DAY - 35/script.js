// object class

class Car {
  start() {
    console.log("start");
  }

  stop() {
    console.log("Stop");
  }

  break() {
    console.log("break");
  }
}

let obj = new Car();
obj.start();
obj.break();
obj.stop();
