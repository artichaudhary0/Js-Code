// object

// const NFTStore = {
//   artPieces: [
//     {
//       pieceName: "Emo Flamingos",
//       price: 30,
//       ownerList: [
//         {
//           name: "Fida Ernest",
//           userID: 23849,
//           purchaseDate: "09/13/2021",
//         },
//         {
//           name: "Eric Karger",
//           userID: 23510,
//           purchaseDate: "09/13/2024",
//         },
//       ],
//     },
//     {
//       pieceName: "Where is my bit wallet",
//       price: 100,
//       ownerList: [],
//     },
//   ],
//   storeCredits: 1000,
// };

// console.log(NFTStore.artPieces[0].ownerList[1].purchaseDate);
// price

// console.log(NFTStore.artPieces[0]["pieceName"]);
// console.log(NFTStore.artPieces[0]["price"]);
// console.log(NFTStore.artPieces[0]["ownerList"]);
// console.log(NFTStore.artPieces[0]["ownerList"][0]);
// console.log(NFTStore.artPieces[0]["ownerList"][0]["name"]);
// console.log(NFTStore.artPieces[0]["ownerList"][0]["userID"]);
// console.log(NFTStore.artPieces[0]["ownerList"][0]["purchaseDate"]);

//   console.log(NFTStore.storeCredits)

// var collection = {
//   2548: {
//     album: "Implication",
//     artist: "2face Idibia",
//     tracks: ["Spiritual healing", "you Give Love a Bad Name"],
//   },
//   2468: {
//     album: "Beautiful Imperfection",
//     artist: "Asa",
//     tracks: ["Bed of Stone", "Awe"],
//   },

//   2548: {
//     artist: "R-Kelly",
//     tracks: [],
//   },

//   5439: {
//     album: "Adekunle",
//   },
// };

// console.log(collection[2468].tracks[1]);

// var myMusic = [
//     {
//       "artist": "Billy Joel",
//       "title": "Piano Man",
//       "release_year": 1973,
//       "formats": [
//         "CS",
//         "8T",
//         // console.log(myMusic[0].formats[2])
//         "LP" ],
//       "gold": true
//     },
//     {
//       "artist": "Bob",
//       "title": "Hello",
//       "release_year": 1950,
//       "formats": [
//         "CS",
//         "8T"
//       ]
//     }
//   ];

//   console.log(myMusic[0].formats[2])

/*
object : key  {}
array : index []
*/

let nevil = {
  problems: [
    {
      Diabetes: [
        {
          medications: [
            {
              medicationsClasses: [
                {
                  className: [
                    {
                      associatedDrug: [
                        {
                          name: "asprin",
                          dose: "",
                          strength: "500 mg",
                        },
                      ],
                      "associatedDrug#2": [
                        {
                          name: "somethingElse",
                          dose: "",
                          // console.log(nevil['problems'][0]['Diabetes'][0]['medications'][0]['medicationsClasses][0]['className'][0]['associatedDrug#2'][0]['strength'])
                          strength: "600 mg",
                        },
                      ],
                    },
                  ],
                  className2: [
                    {
                      associatedDrug: [
                        {
                          name: "asprin",
                          dose: "",
                          strength: "500 mg",
                        },
                      ],
                      "associatedDrug#2": [
                        {
                          name: "somethingElse",
                          dose: "",
                          strength: "500 mg",
                        },
                      ],
                    },
                  ],
                },
              ],
            },
          ],
          labs: [
            {
              missing_field: "missing_value",
            },
          ],
        },
      ],
      Asthma: [{}],
    },
    {
      Diabetes: [
        {
          medications: [
            {
              medicationsClasses: [
                {
                  className: [
                    {
                      associatedDrug: [
                        {
                          name: "asprin",
                          dose: "",
                          strength: "500 mg",
                        },
                      ],
                      "associatedDrug#2": [
                        {
                          name: "somethingElse",
                          dose: "",
                          // console.log(nevil['problems'][0]['Diabetes'][0]['medications'][0]['medicationsClasses][0]['className'][0]['associatedDrug#2'][0]['strength'])
                          strength: "600 mg",
                        },
                      ],
                    },
                  ],
                  className2: [
                    {
                      associatedDrug: [
                        {
                          name: "asprin",
                          dose: "",
                          strength: "500 mg",
                        },
                      ],
                      "associatedDrug#2": [
                        {
                          name: "somethingElse",
                          dose: "",
                          strength: "500 mg",
                        },
                      ],
                    },
                  ],
                },
              ],
            },
            {
              medicationsClasses: [
                {
                  className: [
                    {
                      associatedDrug: [
                        {
                          name: "asprin",
                          dose: "",
                          strength: "500 mg",
                        },
                      ],
                      "associatedDrug#2": [
                        {
                          name: "somethingElse",
                          dose: "",
                          // console.log(nevil['problems'][0]['Diabetes'][0]['medications'][0]['medicationsClasses][0]['className'][0]['associatedDrug#2'][0]['strength'])
                          strength: "600 mg",
                        },
                      ],
                    },
                  ],
                  className2: [
                    {
                      associatedDrug: [
                        {
                          name: "asprin",
                          dose: "",
                          strength: "500 mg",
                        },
                      ],
                      "associatedDrug#2": [
                        {
                          name: "somethingElse",
                          dose: "",
                          strength: "500 mg",
                        },
                      ],
                    },
                  ],
                },
              ],
            },
            {
              medicationsClasses: [
                {
                  className: [
                    {
                      associatedDrug: [
                        {
                          name: "asprin",
                          dose: "",
                          strength: "500 mg",
                        },
                      ],
                      "associatedDrug#2": [
                        {
                          name: "somethingElse",
                          dose: "",
                          // console.log(nevil['problems'][0]['Diabetes'][0]['medications'][0]['medicationsClasses][0]['className'][0]['associatedDrug#2'][0]['strength'])
                          strength: "600 mg",
                        },
                      ],
                    },
                  ],
                  className2: [
                    {
                      associatedDrug: [
                        {
                          name: "asprin",
                          dose: "",
                          strength: "500 mg",
                        },
                      ],
                      "associatedDrug#2": [
                        {
                          name: "somethingElse",
                          dose: "",
                          strength: "500000 mg",
                        },
                      ],
                    },
                  ],
                },
              ],
            },
          ],
          labs: [
            {
              missing_field: "missing_value",
            },
          ],
        },
      ],
      Asthma: [{}],
    },
  ],
};

console.log(
  nevil.problems[1].Diabetes[0].medications[2].medicationsClasses[0]
    .className2[0]["associatedDrug#2"][0].strength
);

// console.log(
//   nevil["problems"][0]["Diabetes"][0]["medications"][0][
//     "medicationsClasses"
//   ][0]["className"][0]["associatedDrug#2"][0]["strength"]
// );
