/*
Parameters Function (with Arguments).
Return type in function.
Switch Program.
*/

// function add() {
//   let a = 10
//   let b = 20
//   console.log(a + b);
// }

// add();
// add();
// add();
// add();

function funName(a, b) {
  var c = 11;
  if (c % 2 == 0) {
    return 2;
  } else {
    return 1;
  }
}

var result = funName(20, 20);
console.log(result);
