/*
What is Function ?
Normal Functions.


Scope : 
Global 
local   
    Block scope
    function scope

0 1 1 2 3 5 8 13. . .

*/
// let a = 100;
// function namee() {
//   let firstTerm = 0;
//   let secondTerm = 1;
//   let nextTerm;
//   console.log(firstTerm);
//   console.log(secondTerm);

//   for (let i = 1; i <= 10; i++) {
//     nextTerm = firstTerm + secondTerm;
//     firstTerm = secondTerm;
//     secondTerm = nextTerm;

//     console.log(nextTerm);
//   }
// }

// namee();
