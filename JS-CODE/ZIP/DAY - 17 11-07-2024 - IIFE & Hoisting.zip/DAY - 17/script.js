// IIFE :

// var result = () => {
//   console.log("i7wegfw");
//   return 10;
// };

// console.log(result());

// (() => {
//   console.log("vsyvce");
// })();

// let result = (() => {
//   console.log("frg");
//   return 12;
// })();

// console.log(result);

test();

function test() {
  console.log("Hoisting!!!");
}
