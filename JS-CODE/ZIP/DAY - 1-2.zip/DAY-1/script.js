/* 
document.write() write on browser
alert() // dialogue box
innerHTML // write in tag
console.log()
*/

var namee = "Arti chaudhary"; // user input
var age = 23;
console.log("My name is : ", namee + " <br> my age : " + age);

document.write("My name is : ", namee + " <br> my age : " + age);

// document.getElementById("heading").innerHTML = namee;

// // document.write(namee + " " + age);
// alert(namee);
