/*

Scope : 
type : 
1 : Global scope
2 : Local scope
    function scope
    block scope
*/

/*
undefined error 20 
*/

// console.log(b);
// var b = 20;

/*
var b 
console.log(b)
var b = 20

*/

var a = 10; // global var

if (10 < 20) {
  a = 20;
}

{
  const c = 20;
}
console.log(c); //
