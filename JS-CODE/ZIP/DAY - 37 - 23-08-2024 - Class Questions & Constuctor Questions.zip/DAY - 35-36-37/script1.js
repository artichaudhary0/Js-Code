// consturctor with default parameter

class Product {
  constructor(name, price, discount = 0) {
    this.name = name;
    this.price = price;
    this.discount = discount;
    this.finalPrice = this.price - this.price * (this.discount / 100);
  }
}
const p1 = new Product("mobile", 21423, 10);
const p2 = new Product("laptop", 214263);

console.log(p1.finalPrice);
console.log(p2.finalPrice);

// constructor with optional parameter

class Rectangle {
  constructor(height, width, option = {}) {
    this.width = width;
    this.height = height;
    this.color = option.color || "black";
    this.boderWidth = option.boderWidth || 1;
  }

  area() {
    return this.width * this.height;
  }
}

const rec1 = new Rectangle(10, 20, { color: "red", boderWidth: 2 });
const rec2 = new Rectangle(13, 43);

console.log(rec1.color); // red
console.log(rec2.color); // black

console.log(rec1.boderWidth); // 2
console.log(rec2.boderWidth); // 1
